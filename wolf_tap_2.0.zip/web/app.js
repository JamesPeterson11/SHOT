const tg=window.Telegram?.WebApp; tg?.ready(); tg?.expand();

const KEY="wolf_tap_2_save";
const defaults={
 coins:0,xp:0,level:1,energy:100,combo:1,taps:0,mission:0,streak:1,
 nick:"UNKNOWN WOLF",avatar:1,theme:"gold",stars:0,shots:0,referrals:0,
 lastInvite:0,admin:false,claimedDaily:false,critCount:0
};
let s={...defaults,...(JSON.parse(localStorage.getItem(KEY)||"null")||{})};
const $=id=>document.getElementById(id);
const save=()=>localStorage.setItem(KEY,JSON.stringify(s));
const fmt=n=>Intl.NumberFormat("ru-RU",{notation:"compact",maximumFractionDigits:1}).format(n);

const audio={ctx:null};
function sound(type){
  try{
    audio.ctx ||= new (window.AudioContext||window.webkitAudioContext)();
    const o=audio.ctx.createOscillator(),g=audio.ctx.createGain();
    o.type=type==="crit"?"sawtooth":"square";
    o.frequency.value=type==="crit"?680:190+Math.random()*90;
    g.gain.value=.025;o.connect(g);g.connect(audio.ctx.destination);
    o.start();g.gain.exponentialRampToValueAtTime(.0001,audio.ctx.currentTime+.09);o.stop(audio.ctx.currentTime+.1);
  }catch{}
}

function render(){
 $("balance").textContent=fmt(s.coins);
 $("energy").textContent=Math.floor(s.energy);
 $("level").textContent=`LVL ${s.level}`;
 const ranks=["ROOKIE","BROKER","DEALER","WHALE","WOLF","LEGEND","TYCOON"];
 $("rank").textContent=ranks[Math.min(6,Math.floor((s.level-1)/2))];
 const need=100+(s.level-1)*65;
 $("xpText").textContent=`${Math.min(need,s.xp)} / ${need} XP`;
 $("xpBar").style.width=`${Math.min(100,s.xp/need*100)}%`;
 $("combo").textContent=`COMBO x${s.combo}`;
 $("streak").textContent=`🔥 ${s.streak}`;
 $("missionBar").style.width=`${Math.min(100,s.mission)}%`;
 $("claimMission").textContent=s.mission>=100?"+2,500 $W — CLAIM":`${s.mission} / 100`;
 $("claimMission").disabled=s.mission<100;
 $("avatarMini").querySelector("img").src=`assets/legend_${s.avatar}.jpeg`;
}

function tap(e){
 if(s.energy<=0){toast("⚡ ЭНЕРГИЯ В НОЛЬ — ОТДЫХАЙ");return}
 s.energy--;
 s.taps++;s.mission=Math.min(100,s.mission+1);
 let gain=1+Math.floor(s.combo/7);
 const crit=Math.random()<.055;
 if(crit){gain*=10;s.combo=Math.min(99,s.combo+3);s.critCount++;sound("crit");document.body.classList.add("shake");setTimeout(()=>document.body.classList.remove("shake"),250)}
 else{s.combo=Math.min(99,s.combo+1);sound("tap")}
 if(s.admin)gain*=25;
 s.coins+=gain;s.xp++;
 if(s.xp>=100+(s.level-1)*65){s.xp=0;s.level++;toast(`🏆 LEVEL ${s.level}: ${["ROOKIE","BROKER","DEALER","WHALE","WOLF","LEGEND","TYCOON"][Math.min(6,Math.floor((s.level-1)/2))]}`)}
 float(e.clientX,e.clientY,`+${gain}${crit?" CRIT":""}`);
 moneyRain(crit?7:2);
 if(navigator.vibrate)navigator.vibrate(crit?[18,25,18]:7);
 save();render();
}
function float(x,y,t){const d=document.createElement("div");d.className="float";d.textContent=t;d.style.left=x+"px";d.style.top=y+"px";document.body.appendChild(d);setTimeout(()=>d.remove(),850)}
function moneyRain(n=3){
 for(let i=0;i<n;i++){const d=document.createElement("div");d.className="money";d.textContent=["💵","💸","💰"][Math.floor(Math.random()*3)];
 d.style.left=(Math.random()*100)+"vw";d.style.top=(Math.random()*35)+"vh";d.style.setProperty("--dx",(Math.random()*160-80)+"px");d.style.setProperty("--rot",(Math.random()*90-45)+"deg");document.body.appendChild(d);setTimeout(()=>d.remove(),900)}
}
function toast(t){const d=$("toast");d.textContent=t;d.classList.add("show");clearTimeout(window._toast);window._toast=setTimeout(()=>d.classList.remove("show"),1600)}

function openPanel(name){
 const p=$("panel");
 const panels={
 quests:`<h2>🎯 QUEST BOARD</h2><div class="list">
 ${item("100 TAP DEMON","100 taps in one mission.","+2,500 $W",s.mission>=100,"claimMission()")}
 ${item("PAPER HANDS","10,000 $W balance.","+5,000 $W",s.coins>=10000,"reward(5000)")}
 ${item("CRITICAL MASS","10 critical taps.","+8,000 $W",s.critCount>=10,"reward(8000)")}
 ${item("NIGHT SHIFT","500 total taps.","+12,000 $W",s.taps>=500,"reward(12000)")}
 ${item("WHALE","Reach level 10.","+25,000 $W",s.level>=10,"reward(25000)")}
 </div>`,
 legends:`<h2>🎬 LEGENDARY DISTRICTS</h2><div class="list">
 ${legend("01","WALL STREET","START","Терминал. Костюм. Ноль сомнений.","open")}
 ${legend("02","FIGHT CLUB","1,000 $W","Подпольный зал.","s.coins>=1000")}
 ${legend("03","PROJECT X","5,000 $W","Одна ночь. Очень плохие решения.","s.coins>=5000")}
 ${legend("04","AMERICAN PSYCHO","10,000 $W","Идеальный костюм. Идеально сомнительный портфель.","s.coins>=10000")}
 ${legend("05","NIGHT DRIVE","25,000 $W","Неон, скорость, город.","s.coins>=25000")}
 ${legend("06","BLADE DISTRICT","100,000 $W","Город будущего.","s.coins>=100000")}
 ${legend("07","THE VOID","1,000,000 $W","Там уже не осталось кнопок.","s.coins>=1000000")}
 </div>`,
 casino:`<h2>♠ CASINO — ARCADE MODE</h2><p class="stars">Только виртуальные $W. Никаких реальных ставок или вывода.</p>
 <div class="item"><strong>ROULETTE</strong><div class="roulette" id="wheel">♠</div>
 <div class="casino-row"><input id="bet" type="number" value="100" min="1"><button class="itemBtn gold" onclick="spin()">SPIN</button></div></div>
 <div class="item" style="margin-top:9px"><strong>POKER — 5 CARD BLUFF</strong><p>Нажми DEAL и получи случайную комбинацию.</p><button class="gold" onclick="poker()">DEAL HAND</button><p id="pokerResult"></p></div>`,
 projectx:`<h2>🍾 PROJECT X</h2><div class="item"><strong>CHAOS METER</strong><p>Случайный arcade-ивент каждые 24 часа.</p><div class="bar"><i style="width:${Math.min(100,(s.shots%10)*10)}%"></i></div><button class="gold" onclick="chaos()">ROLL THE NIGHT</button></div>
 <div class="item"><strong>SHOTS</strong><p>Фантазийный ресурс для мини-игр.</p><button onclick="s.shots++;save();render();toast('+1 SHOT')">+1 SHOT</button></div>`,
 themes:`<h2>◈ STYLE LAB</h2><div class="theme-grid">
 <button class="theme" onclick="theme('gold')"><b>GOLD RUSH</b><small>Wall Street noir</small></button>
 <button class="theme" onclick="theme('cyber')"><b>NEON</b><small>Future district</small></button>
 <button class="theme" onclick="theme('club')"><b>FIGHT CLUB</b><small>Red basement</small></button>
 <button class="theme" onclick="theme('drive')"><b>NIGHT DRIVE</b><small>Midnight</small></button></div>
 <h2 style="margin-top:20px">🖼 AVATAR VAULT</h2><div class="photo-grid">${Array.from({length:10},(_,i)=>`<button class="photo ${s.avatar===i+1?"selected":""}" onclick="avatar(${i+1})"><img src="assets/legend_${i+1}.jpeg"></button>`).join("")}</div>`,
 vault:`<h2>💎 STAR VAULT</h2><p class="stars">Mock Telegram Stars shop. Payment integration is intentionally not wired into this prototype.</p><div class="list">
 <div class="item"><strong>VIP GOLD THEME</strong><p>Exclusive gold UI.</p><button class="gold" onclick="buyStars(25,'theme')">⭐ 25 STARS</button></div>
 <div class="item"><strong>WHALE AVATAR PACK</strong><p>Unlock cosmetic avatar slots.</p><button class="gold" onclick="buyStars(50,'avatar')">⭐ 50 STARS</button></div>
 <div class="item"><strong>INFINITE ENERGY — 1H</strong><p>Cosmetic/demo booster.</p><button class="gold" onclick="buyStars(75,'energy')">⭐ 75 STARS</button></div></div>
 <h2 style="margin-top:20px">🤝 REFERRALS</h2><div class="item"><strong>ANTI-SPAM NETWORK</strong><p>Реферальная награда выдаётся только после реального открытия Mini App, а между наградами действует cooldown.</p><button onclick="referral()">GENERATE INVITE</button></div>`,
 profile:`<h2>☻ YOUR EMPIRE</h2><div class="item"><strong>NICKNAME</strong><div class="casino-row"><input class="name-input" id="nick" maxlength="18" value="${esc(s.nick)}"><button class="gold" onclick="rename()">SAVE</button></div></div>
 <div class="item"><strong>STATS</strong><p>${s.taps.toLocaleString()} taps · ${s.coins.toLocaleString()} $W · LVL ${s.level} · ${s.critCount} crits · ${s.referrals} referrals</p></div>
 <div class="item"><strong>ADMIN TERMINAL</strong><p>Demo only. Пароль проверяется локально; для production нужен server-side auth.</p><div class="casino-row"><input class="name-input" id="adminCode" type="password" placeholder="ADMIN CODE"><button onclick="adminLogin()">LOGIN</button></div></div>`
 };
 p.innerHTML=panels[name]||panels.profile;$("modal").classList.remove("hidden");
}
function item(a,b,c,ready,fn){return `<div class="item"><strong>${a}</strong><p>${b}</p><button onclick="${ready?fn:"toast('ЕЩЁ НЕМНОГО ФАРМА')}" class="${ready?"gold":""}">${ready?c:"IN PROGRESS"}</button></div>`}
function legend(a,b,c,d,cond){return `<div class="item"><strong>${a} · ${b}</strong><p>${c} · ${d}</p><button class="${cond==="open"||cond==="true"||evalSafe(cond)?'gold':''}" onclick="${evalSafe(cond)?`toast('ENTERED: ${b}')`:`toast('НУЖНО БОЛЬШЕ $W')`}">${evalSafe(cond)?"ENTER":"LOCKED"}</button></div>`}
function evalSafe(x){if(x==="open")return true;try{return Function("s","return !!("+x+")")(s)}catch{return false}}
function reward(n){s.coins+=n;save();render();toast(`+$${n.toLocaleString()}W`);openPanel("quests")}
function claimMission(){if(s.mission>=100){s.coins+=2500;s.mission=0;save();render();toast("+2,500 $W");openPanel("quests")}}
function spin(){
 const bet=Math.max(1,Math.floor(Number($("bet").value)||1));
 if(bet>s.coins){toast("НЕ ХВАТАЕТ $W");return}
 s.coins-=bet;const win=Math.random()<.47;const wheel=$("wheel");wheel.style.transform=`rotate(${720+Math.random()*720}deg)`;
 setTimeout(()=>{if(win){s.coins+=bet*2;toast(`🎰 HIT +${bet*2} $W`)}else toast("🎰 HOUSE WINS");save();render()},1400)
}
function poker(){const cards=["A♠","K♦","Q♣","10♥","7♠"];const win=Math.random()<.35; if(win){s.coins+=500;toast("♠ BLUFF SUCCESS +500 $W")}else toast("♠ BAD HAND");$("pokerResult").textContent=`HAND: ${cards.join("  ")} — ${win?"WIN":"FOLD"}`;save();render()}
function chaos(){const n=Math.floor(Math.random()*5)+1;s.shots+=n;s.coins+=n*100;save();render();toast(`🍾 CHAOS +${n} SHOTS / +${n*100} $W`)}
function theme(t){const c={gold:["#ffc62e","#ff6a00"],cyber:["#00e7ff","#765cff"],club:["#ff3154","#ff003c"],drive:["#ffb347","#ff6a00"]}[t];document.documentElement.style.setProperty("--gold",c[0]);document.documentElement.style.setProperty("--orange",c[1]);s.theme=t;save();toast("STYLE EQUIPPED")}
function avatar(n){s.avatar=n;save();render();toast("AVATAR EQUIPPED");openPanel("themes")}
function rename(){const n=$("nick").value.trim().replace(/[<>]/g,"");if(n.length<2){toast("СЛИШКОМ КОРОТКО");return}s.nick=n;s.nick=s.nick.toUpperCase();save();toast("NICKNAME UPDATED");openPanel("profile")}
function buyStars(cost,what){s.stars+=cost;save();toast(`⭐ DEMO PURCHASE: ${cost} STARS`)}
function referral(){
 const now=Date.now();
 if(now-s.lastInvite<60000){toast("ANTI-SPAM: ПОДОЖДИ МИНУТУ");return}
 s.lastInvite=now;save();
 const user=tg?.initDataUnsafe?.user?.id||"local";const link=`https://t.me/WolfTapBot?start=ref_${user}_${Math.random().toString(36).slice(2,7)}`;
 navigator.clipboard?.writeText(link);toast("INVITE COPIED — награда после реального открытия");
}
function adminLogin(){
 const v=$("adminCode").value;
 if(v==="Зелёная-Бурда"){s.admin=true;s.coins+=100000000;s.energy=100;s.level=99;s.xp=0;s.stars+=9999;s.shots+=999;save();render();toast("☢ ADMIN MODE ENABLED");openPanel("profile")}
 else toast("ACCESS DENIED");
}
function esc(x){return String(x).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;")}

$("tapButton").addEventListener("pointerdown",tap);
$("claimMission").onclick=claimMission;
$("avatarMini").onclick=()=>openPanel("themes");
$("close").onclick=()=>$("modal").classList.add("hidden");
$("modal").addEventListener("click",e=>{if(e.target.id==="modal")$("modal").classList.add("hidden")});
document.querySelectorAll("[data-panel]").forEach(x=>x.addEventListener("click",()=>openPanel(x.dataset.panel)));
$("easterEgg").onclick=()=>toast("🤫 Ты нашёл секретную фразу.");
setInterval(()=>{if(s.energy<100){s.energy=Math.min(100,s.energy+1);save();render()}},1000);
setInterval(()=>{s.combo=Math.max(1,s.combo-1);render()},5000);
theme(s.theme);render();
moneyRain(12);
