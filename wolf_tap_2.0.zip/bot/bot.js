import 'dotenv/config';
import {Telegraf,Markup} from 'telegraf';
const bot=new Telegraf(process.env.BOT_TOKEN);
const url=process.env.WEBAPP_URL;
bot.start(ctx=>ctx.reply(
`🐺 WOLF/TAP 2.0\n\nТерминал открыт.\nФарм → квесты → легендарные комнаты → arcade casino.\n\nВсе игровые балансы виртуальные.`,
Markup.inlineKeyboard([Markup.button.webApp("⚡ OPEN WOLF/TAP",url)])
));
bot.command("play",ctx=>ctx.reply("Терминал:",Markup.inlineKeyboard([Markup.button.webApp("💰 MAKE MONEY",url)])));
bot.command("help",ctx=>ctx.reply("Команды: /start /play /help"));
bot.launch();console.log("WOLF/TAP 2.0 running");
process.once("SIGINT",()=>bot.stop("SIGINT"));process.once("SIGTERM",()=>bot.stop("SIGTERM"));
