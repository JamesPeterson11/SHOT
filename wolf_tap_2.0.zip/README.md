# WOLF/TAP 2.0 — Telegram Mini App

A deliberately over-the-top fictional tap-to-earn / arcade economy prototype.

## Important
All $W, roulette, poker, "bets", shots and casino mechanics are **virtual game mechanics only**.
There is no cash-out, no real-money wagering, and no purchase of cryptocurrency in this demo.

The admin cheat is intentionally a client-side demo switch. Never ship a plaintext admin password in a production client.
For production, validate admin privileges on a server.

## Included
- Tap arena with energy, combo, crits and shake effects
- Money rain / particles
- Synthesized WebAudio soundtrack and SFX (no copyrighted audio bundled)
- Quest board and daily missions
- Legends / movie-inspired zones with generic labels
- Project X room
- Fight Club room
- American Psycho room
- Night Drive
- Blade District
- Vault / Casino
- Virtual roulette and poker
- "Shots" as a fictional arcade resource, not alcohol sales
- Referral anti-abuse cooldown and invite tracking
- Avatar selection from the supplied images
- Nickname editing
- Themes and wallpapers
- Donation/star shop as a **mock UI** (no payment processing)
- Admin demo panel with the user-supplied password
- Easter egg phrase: «Шоты, бабки, тёлки и ставки»
- Telegram WebApp integration
- Local persistence

## Run

### Frontend
```bash
cd web
python -m http.server 8080
```

Open it through an HTTPS tunnel when connecting it to Telegram.

### Bot
```bash
cd bot
npm install
cp .env.example .env
# set BOT_TOKEN and WEBAPP_URL
npm start
```

For a real launch, move all balances, referrals, roulette outcomes, quests and admin authorization to a backend.
